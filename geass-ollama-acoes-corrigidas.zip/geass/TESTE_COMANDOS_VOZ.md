# Teste dos comandos de voz

Esta versão preserva o backend Ollama do arquivo fornecido. Antes de testar o
fallback de IA, deixe o Ollama aberto e confirme que o modelo existe:

```powershell
ollama pull qwen2.5:0.5b
```

Inicie a API Python e o front-end em terminais separados. Use os comandos na
ordem abaixo para validar cada fluxo.

## Login

1. `Preencher usuário com [usuário]`
2. `Preencher senha com [senha]`
3. `Fazer login`

## Criar conta bancária

1. `Criar conta bancária`
2. `Preencher nome do banco com Banco Teste`
3. `Preencher número de roteamento com 123456789`
4. `Preencher número da conta com 123456789`
5. `Salvar`

## Logout

- `Fazer logout`
- `Sair da conta`

## Teste sem microfone

Abra `http://127.0.0.1:8000/docs`, use `POST /executar-texto` e envie o texto
do comando. O navegador deve executar a ação no próximo ciclo de consulta.

Abra o console do navegador com `F12` para ver mensagens iniciadas por `⚡`,
`✅` ou `⚠️`. O backend precisa exibir `Ação registrada para o React`.
